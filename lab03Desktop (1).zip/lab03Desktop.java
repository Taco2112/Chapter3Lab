public class lab03Desktop {
	public static void main(String args[]) {
	
		System.out.println("Lab03, 100 Point Version");
		//System.out.println("lab03, 90ish Point Version");
		//System.out.println("Lab03, 80 Point Version");
		
		
		System.out.println("");
		//ik line 6 is ya know 
		//Below establishes strings,one print and division statement equation thing
		
		
		//lines 16 -20 effects the starting milliseconds
		int staringmilli = 10000123; 
		int startingSeconds = 10000; 
		//System.out.println("Starting seconds: " + startingSeconds);
		System.out.println("Starting milli-seconds: " + staringmilli);
		
		
		int hoursAnswer = startingSeconds /= 3600;
		String hr = "Hours: "; 
		String min= "Minutes: ";
		String sec= "Seconds: ";
		String mili = "Milli Seconds: ";
		//It is aware 22-25 has an easier way as seen in 18 
		
		//all equations and math is below 
		int startingSec = 10000; 
		int secondsDet = startingSec %= 3600;
		int minutesAnswer = secondsDet /= 60 ;
		int secondsAnswer = startingSec %= 60;
		//below line 35 is 100 point 
		int milli = staringmilli -= 10000000 ;
		// math ends here below this lies printing
		

		// TestingCODE-->System.out.println(startingSeconds /= 3600 );
		System.out.println(hr + hoursAnswer);
		System.out.println(min + minutesAnswer);
		System.out.println(sec + secondsAnswer); 
		
		
		// thats all folks --> now below is what makes up the hundo point version(there's different ways of getting results)
		
		System.out.println(mili + milli);

	}

}
